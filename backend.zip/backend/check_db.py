import sqlite3, os
DB = os.path.join(os.path.dirname(__file__), "brain_erp.db")
conn = sqlite3.connect(DB)
tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()]
print("TABLES:", tables)
print("rfqs cols:", [r[1] for r in conn.execute("PRAGMA table_info(rfqs)").fetchall()])
print("master_suppliers cols:", [r[1] for r in conn.execute("PRAGMA table_info(master_suppliers)").fetchall()])
print("tds_sections cols:", [r[1] for r in conn.execute("PRAGMA table_info(tds_sections)").fetchall()])
conn.close()
