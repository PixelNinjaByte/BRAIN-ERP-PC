"""Brain ERP — Login screen (desktop)."""

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QLabel,
)

from .api_client import ApiClient, ApiError


class LoginWindow(QWidget):
    logged_in = pyqtSignal(dict)  # session payload from ApiClient.login()

    def __init__(self, api: ApiClient):
        super().__init__()
        self.api = api
        self.setWindowTitle("Brain ERP — Sign in")
        self.setFixedSize(380, 260)
        self._build_ui()

    def _build_ui(self) -> None:
        title = QLabel("Brain ERP")
        title.setStyleSheet("font-size: 22px; font-weight: 700; color: #2563eb;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        subtitle = QLabel("Sign in to continue")
        subtitle.setStyleSheet("color: #6b7280; margin-bottom: 8px;")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.username = QLineEdit()
        self.username.setPlaceholderText("admin")
        self.password = QLineEdit()
        self.password.setPlaceholderText("Password")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.username.returnPressed.connect(self._do_login)
        self.password.returnPressed.connect(self._do_login)

        form = QFormLayout()
        form.addRow("Username", self.username)
        form.addRow("Password", self.password)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet("color: #dc2626;")
        self.error_label.setWordWrap(True)

        self.login_btn = QPushButton("Sign in")
        self.login_btn.setDefault(True)
        self.login_btn.setStyleSheet(
            "QPushButton { background: #2563eb; color: white; padding: 8px; border-radius: 6px; font-weight: 600; }"
            "QPushButton:disabled { background: #93c5fd; }"
        )
        self.login_btn.clicked.connect(self._do_login)

        layout = QVBoxLayout()
        layout.setContentsMargins(28, 24, 28, 24)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addSpacing(8)
        layout.addLayout(form)
        layout.addWidget(self.error_label)
        layout.addSpacing(4)
        layout.addWidget(self.login_btn)
        self.setLayout(layout)
        self.username.setFocus()

    def clear(self) -> None:
        self.username.clear()
        self.password.clear()
        self.error_label.setText("")
        self.username.setFocus()

    def _do_login(self) -> None:
        username = self.username.text().strip()
        password = self.password.text()
        if not username or not password:
            self.error_label.setText("Enter both username and password.")
            return
        self.login_btn.setEnabled(False)
        self.login_btn.setText("Signing in…")
        self.error_label.setText("")
        try:
            session = self.api.login(username, password)
            self.logged_in.emit(session)
        except ApiError as e:
            self.error_label.setText(str(e))
        finally:
            self.login_btn.setEnabled(True)
            self.login_btn.setText("Sign in")
