"""
Brain ERP – Main window shell (post-login).

Navigation model
~~~~~~~~~~~~~~~~
A QStackedWidget hosts all screens. The sidebar shows top-level nav entries.
A T-code bar at the top lets power users jump directly (e.g. type "MM01" and
press Enter).

Currently live screens
~~~~~~~~~~~~~~~~~~~~~~
  HOME  → DashboardWidget
  MM01  → MM01Widget  (Create Material + list)

All other T-codes are routed to a "Coming Soon" placeholder so the sidebar
can show every module without crashing.
"""

from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QLabel, QPushButton, QFrame, QLineEdit, QListWidget, QListWidgetItem,
    QStackedWidget, QSizePolicy,
)

from .api_client import ApiClient, ApiError
from .mm01_widget import MM01Widget
from .dashboard_widget import DashboardWidget
from .skeleton_card import SkeletonCardRow
from .po_widget import POWidget
from .migo_widget import MIGOWidget
from .pr_widget import PRWidget
from .supplier_invoice_widget import SupplierInvoiceWidget
from .supplier_widget import SupplierWidget
from .rfq_widget import RFQWidget
from .purchase_return_widget import PurchaseReturnWidget
from .reports_widget import ReportsWidget
from .material_import_widget import MaterialImportWidget


# ──────────────────────────────────────────────────────────────────────────────
# T-code routing table
# ──────────────────────────────────────────────────────────────────────────────

#  tcode → stack index (or None → "coming soon")
_TCODE_INDEX: dict[str, int] = {
    "HOME": 0,
    "MM01": 1,
    "MM02": 1,
    "MM03": 1,
    "ME21N": 2,
    "ME23N": 2,
    "ME2L": 2,
    "ME2M": 2,
    "ME28": 2,
    "ME29N": 2,
    "PO": 2,
    "MIGO": 3,
    "GRN": 3,
    "MB51": 3,
    "ME51N": 4,
    "ME53N": 4,
    "PR": 4,
    "MR01": 5,
    "MIRO": 5,
    "LT01": 5,
    "VK11": 5,
    "XK01": 6,
    "XK02": 6,
    "SUPP": 6,
    "ME41": 7,
    "ME47": 7,
    "RFQ": 7,
    "PRTN": 8,
    "ZMRP": 9,
    "ME2PN": 9,
    "ZMMR": 9,
    "ZREP": 9,
    "ZMMI": 10,
}

# Sidebar nav entries: (display label, tcode, section_header?)
_NAV_ITEMS: list[tuple[str, str | None, bool]] = [
    ("🏠  Home",                     "HOME",  False),
    ("MATERIALS MANAGEMENT",        None,    True),
    ("MM01 · Create Material",      "MM01",  False),
    ("MM03 · Materials Directory",  "MM03",  False),
    ("ZMMI · Batch CSV Import",     "ZMMI",  False),
    ("INVENTORY & MOVEMENTS",       None,    True),
    ("MIGO · Goods Movement",       "MIGO",  False),
    ("LT01 · Stock Transfers",      "LT01",  False),
    ("PRTN · Purchase Returns",     "PRTN",  False),
    ("PURCHASING (P2P)",            None,    True),
    ("ME21N · Purchase Orders",     "ME21N", False),
    ("ME51N · Purchase Requisitions","ME51N", False),
    ("ME41 · RFQ & Quotations",     "ME41",  False),
    ("MR01 · Supplier Invoices",    "MR01",  False),
    ("XK01 · Supplier Master",      "XK01",  False),
    ("PROCUREMENT ANALYTICS",       None,    True),
    ("ME2PN · Status Pipeline",     "ME2PN", False),
    ("ZMRP · Reorder Stock",        "ZMRP",  False),
    ("ZMMR · Procurement Reports",  "ZMMR",  False),
    ("ROADMAP / COMING SOON",       None,    True),
    ("VA05 · Sales & Distribution", "VA05",  False),
    ("FB50 · Finance & Accounting", "FB50",  False),
    ("PA30 · Human Resources",      "PA30",  False),
    ("COOIS · Production Planning", "COOIS", False),
    ("QA32 · Quality Management",   "QA32",  False),
    ("AURA · AI ERP Assistant",     "AURA",  False),
    ("SU01 · Administration",       "SU01",  False),
]


# ──────────────────────────────────────────────────────────────────────────────
# Coming-soon placeholder with animated skeleton preview
# ──────────────────────────────────────────────────────────────────────────────

class _ComingSoon(QWidget):
    def __init__(self, label: str = ""):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(12)

        icon = QLabel("🚧")
        icon.setFont(QFont("Segoe UI Emoji", 42))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel(f"{label}\nComing Soon")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: 700; color: #111827;")

        sub = QLabel(
            "This module is on the roadmap.\n"
            "The backend logic is already ported — UI components are loading."
        )
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setStyleSheet("color: #4b5563; font-size: 12px;")
        sub.setWordWrap(True)

        layout.addWidget(icon)
        layout.addWidget(title)
        layout.addWidget(sub)
        layout.addSpacing(16)

        # Animated skeleton loader row from Uiverse (warm-wasp-21)
        skeleton_box = QFrame()
        skeleton_box.setStyleSheet("background: transparent;")
        s_layout = QHBoxLayout(skeleton_box)
        s_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.skeleton_row = SkeletonCardRow(count=2, parent=self)
        s_layout.addWidget(self.skeleton_row)
        layout.addWidget(skeleton_box)


# ──────────────────────────────────────────────────────────────────────────────
# Main window
# ──────────────────────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    logged_out = pyqtSignal()

    def __init__(self, api: ApiClient, session: dict):
        super().__init__()
        self.api = api
        self.session = session
        self.setWindowTitle("Brain ERP")
        self.resize(1180, 800)
        self.setMinimumSize(900, 600)
        self._build_ui()

    # ---------------------------------------------------------------- UI

    def _build_ui(self) -> None:
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._make_topbar())

        body = QSplitter(Qt.Orientation.Horizontal)
        body.setHandleWidth(1)
        body.setStyleSheet("QSplitter::handle { background: #e5e7eb; }")
        body.addWidget(self._make_sidebar())
        body.addWidget(self._make_content_area())
        body.setStretchFactor(0, 0)
        body.setStretchFactor(1, 1)
        body.setSizes([220, 960])

        root.addWidget(body, 1)
        self.setCentralWidget(central)

    # ── top bar ──────────────────────────────────────────────────────────

    def _make_topbar(self) -> QFrame:
        bar = QFrame()
        bar.setFixedHeight(52)
        bar.setStyleSheet("background: #111827; border-bottom: 1px solid #1f2937;")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(12)

        brand = QLabel("🧠  Brain ERP")
        brand.setStyleSheet("color: white; font-size: 15px; font-weight: 800; letter-spacing: 0.5px;")

        # T-code bar
        tcode_label = QLabel("T-Code:")
        tcode_label.setStyleSheet("color: #9ca3af; font-size: 11px;")
        self.tcode_input = QLineEdit()
        self.tcode_input.setPlaceholderText("e.g. MM01, FB50, PA30 …")
        self.tcode_input.setFixedWidth(200)
        self.tcode_input.setStyleSheet(
            "QLineEdit { background: #1f2937; color: white; border: 1px solid #374151;"
            " border-radius: 5px; padding: 5px 10px; font-size: 12px; }"
            "QLineEdit:focus { border-color: #2563eb; }"
        )
        self.tcode_input.returnPressed.connect(self._on_tcode_enter)

        go_btn = QPushButton("Go")
        go_btn.setFixedWidth(44)
        go_btn.setStyleSheet(
            "QPushButton { background: #2563eb; color: white; border: none;"
            " border-radius: 5px; padding: 5px 10px; font-weight: 700; }"
            "QPushButton:hover { background: #1d4ed8; }"
        )
        go_btn.clicked.connect(self._on_tcode_enter)

        who = self.session.get("full_name") or self.session.get("username") or ""
        who_lbl = QLabel(f"👤  {who}")
        who_lbl.setStyleSheet("color: #d1d5db; font-size: 11px;")

        logout_btn = QPushButton("Sign out")
        logout_btn.setStyleSheet(
            "QPushButton { background: #374151; color: white; border: none;"
            " padding: 6px 14px; border-radius: 5px; font-size: 11px; }"
            "QPushButton:hover { background: #4b5563; }"
        )
        logout_btn.clicked.connect(self._do_logout)

        layout.addWidget(brand)
        layout.addSpacing(16)
        layout.addWidget(tcode_label)
        layout.addWidget(self.tcode_input)
        layout.addWidget(go_btn)
        layout.addStretch(1)
        layout.addWidget(who_lbl)
        layout.addSpacing(8)
        layout.addWidget(logout_btn)
        return bar

    # ── sidebar ───────────────────────────────────────────────────────────

    def _make_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setFixedWidth(220)
        sidebar.setStyleSheet("background: #1f2937;")
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 8, 0, 8)
        layout.setSpacing(0)

        self.nav_list = QListWidget()
        self.nav_list.setStyleSheet(
            "QListWidget { background: #1f2937; border: none; outline: none; }"
            "QListWidget::item { color: #d1d5db; padding: 10px 16px;"
            " border-radius: 0px; font-size: 12px; }"
            "QListWidget::item:selected { background: #2563eb; color: white; }"
            "QListWidget::item:hover:!selected { background: #374151; }"
        )
        self.nav_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self._nav_tcode_map: dict[int, str] = {}

        for idx, (label, tcode, is_header) in enumerate(_NAV_ITEMS):
            item = QListWidgetItem(label)
            if is_header:
                item.setFlags(Qt.ItemFlag.NoItemFlags)
                item.setFont(QFont("", 9, QFont.Weight.Bold))
                item.setForeground(Qt.GlobalColor.gray)
                item.setBackground(Qt.GlobalColor.transparent)
            else:
                self._nav_tcode_map[self.nav_list.count()] = tcode or ""
            self.nav_list.addItem(item)

        self.nav_list.setCurrentRow(0)
        self.nav_list.itemClicked.connect(self._on_nav_click)

        layout.addWidget(self.nav_list)
        return sidebar

    # ── content / stack ───────────────────────────────────────────────────

    def _make_content_area(self) -> QWidget:
        wrapper = QWidget()
        wrapper.setStyleSheet("background: #f1f5f9;")
        layout = QVBoxLayout(wrapper)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.stack = QStackedWidget()

        # Index 0 → Dashboard
        self.dashboard = DashboardWidget(navigate=self.navigate, session=self.session)
        self.stack.addWidget(self.dashboard)

        # Index 1 → MM01 / MM03
        self.mm01 = MM01Widget(self.api)
        self.stack.addWidget(self.mm01)

        # Index 2 → POWidget (ME21N / ME23N)
        self.po_widget = POWidget(self.api)
        self.stack.addWidget(self.po_widget)

        # Index 3 → MIGOWidget (MIGO)
        self.migo_widget = MIGOWidget(self.api)
        self.stack.addWidget(self.migo_widget)

        # Index 4 → PRWidget (ME51N / ME53N)
        self.pr_widget = PRWidget(self.api)
        self.stack.addWidget(self.pr_widget)

        # Index 5 → SupplierInvoiceWidget (MR01 / LT01)
        self.invoice_widget = SupplierInvoiceWidget(self.api)
        self.stack.addWidget(self.invoice_widget)

        # Index 6 → SupplierWidget (XK01 / XK02)
        self.supplier_widget = SupplierWidget(self.api)
        self.stack.addWidget(self.supplier_widget)

        # Index 7 → RFQWidget (ME41 / ME47)
        self.rfq_widget = RFQWidget(self.api)
        self.stack.addWidget(self.rfq_widget)

        # Index 8 → PurchaseReturnWidget (PRTN)
        self.return_widget = PurchaseReturnWidget(self.api)
        self.stack.addWidget(self.return_widget)

        # Index 9 → ReportsWidget (ZMRP / ME2PN / ZMMR)
        self.reports_widget = ReportsWidget(self.api)
        self.stack.addWidget(self.reports_widget)

        # Index 10 → MaterialImportWidget (ZMMI)
        self.import_widget = MaterialImportWidget(self.api)
        self.stack.addWidget(self.import_widget)

        # Index 11 → Coming Soon (shared)
        self._coming_soon = _ComingSoon()
        self.stack.addWidget(self._coming_soon)

        layout.addWidget(self.stack)
        return wrapper

    # ---------------------------------------------------------------- navigation

    def navigate(self, tcode: str) -> None:
        """Navigate to the screen for *tcode*. Called by sidebar, T-code bar,
        and DashboardWidget tile clicks."""
        tcode = tcode.strip().upper()
        idx = _TCODE_INDEX.get(tcode, 11)   # default → Coming Soon (index 11)
        self.stack.setCurrentIndex(idx)
        self.tcode_input.clear()

        # Keep sidebar selection in sync
        for row in range(self.nav_list.count()):
            mapped = self._nav_tcode_map.get(row, "")
            if mapped == tcode:
                self.nav_list.setCurrentRow(row)
                break

    def _on_nav_click(self, item: QListWidgetItem) -> None:
        row = self.nav_list.row(item)
        tcode = self._nav_tcode_map.get(row, "")
        if tcode:
            self.navigate(tcode)

    def _on_tcode_enter(self) -> None:
        tcode = self.tcode_input.text().strip()
        if tcode:
            self.navigate(tcode)

    # ---------------------------------------------------------------- logout

    def _do_logout(self) -> None:
        try:
            self.api.logout()
        except ApiError:
            pass
        self.logged_out.emit()
