"""Brain ERP — owns the single ApiClient instance and swaps LoginWindow <-> MainWindow."""

import sys

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPalette, QColor
from PyQt6.QtWidgets import QApplication

from .api_client import ApiClient
from .login_window import LoginWindow
from .main_window import MainWindow

_STYLESHEET = """
QWidget {
    font-size: 13px;
    color: #111827;
}

QGroupBox {
    font-weight: 600;
    margin-top: 10px;
    border: 1px solid #e5e7eb;
    border-radius: 6px;
    padding-top: 10px;
    color: #111827;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: #111827;
}

QLabel {
    color: #111827;
}

QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox {
    padding: 5px 8px;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    background: #ffffff;
    color: #111827;
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {
    border: 1.5px solid #2563eb;
}

QComboBox {
    padding: 5px 8px;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    background: #ffffff;
    color: #111827;
}

QComboBox QAbstractItemView {
    background: #ffffff;
    color: #111827;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}

QCheckBox {
    color: #111827;
}

QTabBar::tab {
    padding: 8px 16px;
    color: #111827;
}

QTabBar::tab:selected {
    color: #2563eb;
    font-weight: 600;
}

QTableWidget {
    gridline-color: #e5e7eb;
    background: #ffffff;
    color: #111827;
}

QTableWidget::item {
    color: #111827;
}

QHeaderView::section {
    background: #f9fafb;
    color: #111827;
    font-weight: 600;
    border: none;
    border-bottom: 1px solid #e5e7eb;
    padding: 6px;
}
"""


class AppController:
    def __init__(self, base_url: str):
        self.api = ApiClient(base_url)
        self.main_window: MainWindow | None = None
        self.login_window = LoginWindow(self.api)
        self.login_window.logged_in.connect(self._on_logged_in)
        self.login_window.show()

    def _on_logged_in(self, session: dict) -> None:
        self.main_window = MainWindow(self.api, session)
        self.main_window.logged_out.connect(self._on_logged_out)
        self.main_window.show()
        self.login_window.close()

    def _on_logged_out(self) -> None:
        if self.main_window:
            self.main_window.close()
            self.main_window = None
        self.login_window.clear()
        self.login_window.show()


def run_frontend(base_url: str) -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Brain ERP")
    app.setStyle("Fusion")

    # Enforce standard light-theme palette to prevent OS dark mode from injecting white text
    palette = app.palette()
    palette.setColor(QPalette.ColorRole.Window, QColor("#f8fafc"))
    palette.setColor(QPalette.ColorRole.WindowText, QColor("#111827"))
    palette.setColor(QPalette.ColorRole.Base, QColor("#ffffff"))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor("#f1f5f9"))
    palette.setColor(QPalette.ColorRole.Text, QColor("#111827"))
    palette.setColor(QPalette.ColorRole.Button, QColor("#ffffff"))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor("#111827"))
    app.setPalette(palette)

    app.setStyleSheet(_STYLESHEET)
    controller = AppController(base_url)  # noqa: F841
    return app.exec()
