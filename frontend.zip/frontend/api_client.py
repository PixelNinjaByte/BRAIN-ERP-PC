"""
Brain ERP — HTTP client the PyQt6 screens use to talk to the FastAPI backend.

Provides typed convenience methods for all backend modules:
  - Authentication & Navigation
  - Materials Management (MM01, MM02, MM03)
  - Goods Movements (MIGO)
  - Purchase Orders (ME21N, ME23N)
  - Purchase Requisitions (ME51N, ME53N)
  - Supplier Invoices & Pricing (MR01, LT01, VK11)
  - Suppliers Master (XK01, XK02)
  - Purchase Returns (PRTN)
  - RFQs & Comparison (ME41, ME47)
  - Service Entry Sheets (ML81N)
  - Material Groups (OMSF)
  - Planning & Reports (ZMRP, ME2PN, ZMMR)
  - Bids & Tenders (BID01, BID02)
  - Material CSV Import/Export (ZMMI)
"""

from typing import Any, Optional
import httpx


class ApiError(Exception):
    """Raised for a network failure, a non-2xx response, or success:false."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class ApiClient:
    def __init__(self, base_url: str, timeout: float = 15.0):
        self._base = base_url.rstrip("/")
        self._client = httpx.Client(base_url=self._base, timeout=timeout)

    def close(self) -> None:
        self._client.close()

    @property
    def base_url(self) -> str:
        return self._base

    # ------------------------------------------------------------------ core
    def _request(self, method: str, path: str, **kwargs) -> dict:
        try:
            r = self._client.request(method, path, **kwargs)
        except httpx.HTTPError as e:
            raise ApiError(f"Could not reach the Brain ERP server: {e}") from e

        try:
            body = r.json()
        except ValueError:
            body = {}

        if r.status_code >= 400:
            msg = (body.get("detail") or body.get("error") or f"Request failed ({r.status_code}).") \
                if isinstance(body, dict) else f"Request failed ({r.status_code})."
            raise ApiError(msg, r.status_code)
        if isinstance(body, dict) and body.get("success") is False:
            raise ApiError(body.get("error") or "Request failed.", r.status_code)
        return body if isinstance(body, dict) else {"success": True, "data": body}

    # ------------------------------------------------------------------ auth & nav
    def login(self, username: str, password: str) -> dict:
        return self._request("POST", "/api/auth/login", json={"username": username, "password": password})["data"]

    def logout(self) -> None:
        self._request("POST", "/api/auth/logout")

    def me(self) -> dict:
        return self._request("GET", "/api/auth/me")["data"]

    def switch_company(self, company_id: int) -> dict:
        return self._request("POST", "/api/auth/switch-company", json={"company_id": company_id})["data"]

    def nav_dashboard(self) -> dict:
        res = self._request("GET", "/api/nav/dashboard")
        return res.get("data", res)

    def nav_modules(self) -> list:
        res = self._request("GET", "/api/nav/modules")
        return res.get("data", res) if isinstance(res, dict) else res

    # ------------------------------------------------------------------ MM01/02/03
    def mm_lookups(self) -> dict:
        return self._request("GET", "/api/mm/lookups")["data"]

    def mm_list(self, search: str = "", cat: str = "", type_: str = "", st: str = "active") -> list:
        params = {"search": search, "cat": cat, "type": type_, "st": st}
        return self._request("GET", "/api/mm/materials", params=params)["data"]

    def mm_get(self, item_id: int) -> dict:
        return self._request("GET", f"/api/mm/materials/{item_id}")["data"]

    def mm_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/mm/materials", json=payload)

    def mm_update(self, item_id: int, payload: dict) -> dict:
        return self._request("PUT", f"/api/mm/materials/{item_id}", json=payload)

    def mm_delete(self, item_id: int) -> dict:
        return self._request("DELETE", f"/api/mm/materials/{item_id}")

    def mm_add_uom(self, item_id: int, payload: dict) -> dict:
        return self._request("POST", f"/api/mm/materials/{item_id}/uom", json=payload)

    def mm_delete_uom(self, item_id: int, conv_id: int) -> dict:
        return self._request("DELETE", f"/api/mm/materials/{item_id}/uom/{conv_id}")

    # ------------------------------------------------------------------ MIGO
    def migo_meta(self) -> dict:
        res = self._request("GET", "/api/migo/meta")
        return res.get("data", res)

    def migo_po_lines(self, po_id: int) -> dict:
        res = self._request("GET", f"/api/migo/po/{po_id}")
        return res.get("data", res)

    def migo_post(self, payload: dict) -> dict:
        return self._request("POST", "/api/migo/post", json=payload)

    def migo_get_doc(self, grn_id: int) -> dict:
        res = self._request("GET", f"/api/migo/grn/{grn_id}")
        return res.get("data", res)

    # ------------------------------------------------------------------ PO (ME21N / ME23N)
    def po_lookups(self) -> dict:
        res = self._request("GET", "/api/po/lookups")
        return res.get("data", res)

    def po_list(self, status: str = "", search: str = "") -> list:
        params = {}
        if status:
            params["status"] = status
        if search:
            params["search"] = search
        res = self._request("GET", "/api/po/", params=params)
        return res.get("data", res) if isinstance(res, dict) else res

    def po_get(self, po_id: int) -> dict:
        res = self._request("GET", f"/api/po/{po_id}")
        return res.get("data", res)

    def po_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/po/", json=payload)

    def po_release(self, po_id: int) -> dict:
        return self._request("POST", f"/api/po/{po_id}/release")

    # ------------------------------------------------------------------ PR (ME51N / ME53N)
    def pr_lookups(self) -> dict:
        res = self._request("GET", "/api/pr/lookups")
        return res.get("data", res)

    def pr_list(self, status: str = "") -> list:
        params = {"status": status} if status else {}
        res = self._request("GET", "/api/pr/", params=params)
        return res.get("data", res) if isinstance(res, dict) else res

    def pr_get(self, pr_id: int) -> dict:
        res = self._request("GET", f"/api/pr/{pr_id}")
        return res.get("data", res)

    def pr_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/pr/", json=payload)

    def pr_action(self, pr_id: int, action: str, reason: str = "") -> dict:
        return self._request("POST", f"/api/pr/{pr_id}/action", json={"action": action, "reason": reason})

    # ------------------------------------------------------------------ Suppliers (XK01 / XK02)
    def supplier_lookups(self) -> dict:
        res = self._request("GET", "/api/supplier/lookups")
        return res.get("data", res)

    def supplier_list(self, search: str = "") -> list:
        params = {"search": search} if search else {}
        res = self._request("GET", "/api/supplier/", params=params)
        return res.get("data", res) if isinstance(res, dict) else res

    def supplier_get(self, sup_id: int) -> dict:
        res = self._request("GET", f"/api/supplier/{sup_id}")
        return res.get("data", res)

    def supplier_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/supplier/", json=payload)

    def supplier_update(self, sup_id: int, payload: dict) -> dict:
        return self._request("PUT", f"/api/supplier/{sup_id}", json=payload)

    def supplier_toggle(self, sup_id: int) -> dict:
        return self._request("POST", f"/api/supplier/{sup_id}/toggle")

    # ------------------------------------------------------------------ Invoices (MR01 / LT01 / VK11)
    def mr01_meta(self, po_id: Optional[int] = None) -> dict:
        params = {"po_id": po_id} if po_id else {}
        res = self._request("GET", "/api/mr01/meta", params=params)
        return res.get("data", res)

    def mr01_post(self, payload: dict) -> dict:
        return self._request("POST", "/api/mr01/post", json=payload)

    def lt01_meta(self) -> dict:
        res = self._request("GET", "/api/lt01/meta")
        return res.get("data", res)

    def lt01_stock(self, item_id: int, warehouse_id: int) -> dict:
        res = self._request("GET", "/api/lt01/stock", params={"item_id": item_id, "warehouse_id": warehouse_id})
        return res.get("data", res)

    def lt01_post(self, payload: dict) -> dict:
        return self._request("POST", "/api/lt01/post", json=payload)

    def vk11_meta(self) -> dict:
        res = self._request("GET", "/api/vk11/meta")
        return res.get("data", res)

    def vk11_save(self, payload: dict) -> dict:
        return self._request("POST", "/api/vk11/save", json=payload)

    # ------------------------------------------------------------------ Purchase Returns (PRTN)
    def purchase_return_reasons(self) -> dict:
        res = self._request("GET", "/api/purchase-return/reasons")
        return res.get("data", res)

    def purchase_return_open_grns(self) -> list:
        res = self._request("GET", "/api/purchase-return/open-grns")
        return res.get("data", res) if isinstance(res, dict) else res

    def purchase_return_grn(self, grn_id: int) -> dict:
        res = self._request("GET", f"/api/purchase-return/grn/{grn_id}")
        return res.get("data", res)

    def purchase_return_list(self) -> list:
        res = self._request("GET", "/api/purchase-return/")
        return res.get("data", res) if isinstance(res, dict) else res

    def purchase_return_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/purchase-return/", json=payload)

    def purchase_return_get(self, return_id: int) -> dict:
        res = self._request("GET", f"/api/purchase-return/{return_id}")
        return res.get("data", res)

    # ------------------------------------------------------------------ RFQ & Compare (ME41 / ME47)
    def rfq_lookups(self) -> dict:
        res = self._request("GET", "/api/rfq/lookups")
        return res.get("data", res)

    def rfq_list(self) -> list:
        res = self._request("GET", "/api/rfq/")
        return res.get("data", res) if isinstance(res, dict) else res

    def rfq_get(self, rfq_id: int) -> dict:
        res = self._request("GET", f"/api/rfq/{rfq_id}")
        return res.get("data", res)

    def rfq_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/rfq/", json=payload)

    def rfq_compare(self, rfq_id: int) -> dict:
        res = self._request("GET", f"/api/rfq-compare/{rfq_id}")
        return res.get("data", res)

    def rfq_award(self, rfq_id: int, payload: dict) -> dict:
        return self._request("POST", f"/api/rfq-compare/{rfq_id}/award", json=payload)

    # ------------------------------------------------------------------ Service Entry (ML81N)
    def ses_lookups(self) -> dict:
        res = self._request("GET", "/api/service-entry/lookups")
        return res.get("data", res)

    def ses_list(self) -> list:
        res = self._request("GET", "/api/service-entry/")
        return res.get("data", res) if isinstance(res, dict) else res

    def ses_po_lines(self, po_id: int) -> list:
        res = self._request("GET", f"/api/service-entry/po/{po_id}/lines")
        return res.get("data", res) if isinstance(res, dict) else res

    def ses_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/service-entry/", json=payload)

    def ses_get(self, ses_id: int) -> dict:
        res = self._request("GET", f"/api/service-entry/{ses_id}")
        return res.get("data", res)

    def ses_accept(self, ses_id: int) -> dict:
        return self._request("POST", f"/api/service-entry/{ses_id}/accept")

    def ses_reject(self, ses_id: int, reason: str) -> dict:
        return self._request("POST", f"/api/service-entry/{ses_id}/reject", json={"reason": reason})

    # ------------------------------------------------------------------ Material Groups (OMSF)
    def mat_groups_lookups(self) -> dict:
        res = self._request("GET", "/api/material-groups/lookups")
        return res.get("data", res)

    def mat_groups_list(self) -> list:
        res = self._request("GET", "/api/material-groups/")
        return res.get("data", res) if isinstance(res, dict) else res

    def mat_group_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/material-groups/", json=payload)

    def mat_group_update(self, group_id: int, payload: dict) -> dict:
        return self._request("PUT", f"/api/material-groups/{group_id}", json=payload)

    # ------------------------------------------------------------------ Reports & Planning (ZMRP / ME2PN / ZMMR)
    def reorder_report(self) -> list:
        res = self._request("GET", "/api/reorder/")
        return res.get("data", res) if isinstance(res, dict) else res

    def reorder_create_pr(self, items: list[dict]) -> dict:
        return self._request("POST", "/api/reorder/create-pr", json={"items": items})

    def pending_report(self) -> dict:
        res = self._request("GET", "/api/mm-pending-report/summary")
        return res.get("data", res)

    def mm_reports_summary(self) -> dict:
        res = self._request("GET", "/api/mm-reports/summary")
        return res.get("data", res)

    # ------------------------------------------------------------------ Bids & Tenders (BID01 / BID02)
    def bid_lookups(self) -> dict:
        res = self._request("GET", "/api/bid/lookups")
        return res.get("data", res)

    def bid_list(self) -> list:
        res = self._request("GET", "/api/bid")
        return res.get("data", res) if isinstance(res, dict) else res

    def bid_get(self, bid_id: int) -> dict:
        res = self._request("GET", f"/api/bid/{bid_id}")
        return res.get("data", res)

    def bid_create(self, payload: dict) -> dict:
        return self._request("POST", "/api/bid", json=payload)

    def bid_update_status(self, bid_id: int, status: str) -> dict:
        return self._request("POST", f"/api/bid/{bid_id}/status", json={"status": status})

    # ------------------------------------------------------------------ Material CSV Import/Export (ZMMI)
    def material_import_preview(self, csv_content: str, update_existing: bool = False) -> dict:
        return self._request(
            "POST",
            "/api/mm/import/preview",
            json={"csv_content": csv_content, "update_existing": update_existing},
        )

    def material_import_confirm(self, token: str) -> dict:
        return self._request("POST", "/api/mm/import/confirm", json={"token": token})
