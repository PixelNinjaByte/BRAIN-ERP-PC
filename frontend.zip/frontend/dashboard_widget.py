"""
Brain ERP – Dashboard (Home screen).

Shows all ERP modules as clickable tiles. Live modules open their screen;
planned modules show a "Coming Soon" badge. The tiles are arranged in a
responsive grid using QGridLayout so they scale with the window.

Every tile features a clean white background, an outline highlight on hover,
and an elevated drop shadow effect.
"""

from __future__ import annotations

from typing import Callable, Optional

from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QColor, QPainter, QBrush
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QFrame, QScrollArea, QSizePolicy,
    QGraphicsDropShadowEffect,
)

from .skeleton_card import SkeletonCardRow

# ---------------------------------------------------------------------------
# Module catalogue
# ---------------------------------------------------------------------------

_MODULES = [
    # (title, subtitle, icon, tcode, live?)
    ("Materials Management",  "MM01 · MM03 · Master catalog",    "📦", "MM01",  True),
    ("Purchasing Orders",     "ME21N · ME23N · Create & track",  "🛒", "ME21N", True),
    ("Goods Movement (GRN)",  "MIGO · 101 GRN & receipts",       "🚚", "MIGO",  True),
    ("Purchase Requisitions", "ME51N · ME53N · Internal indent", "📝", "ME51N", True),
    ("Supplier Invoicing",    "MR01 · MIRO & 3-way match",       "🧾", "MR01",  True),
    ("Supplier Master",       "XK01 · XK02 · Vendor directory",  "🏢", "XK01",  True),
    ("RFQ & Quotes",          "ME41 · ME47 · Compare & award",   "📑", "ME41",  True),
    ("Purchase Returns",      "PRTN · Return to vendor & DN",    "↩️", "PRTN",  True),
    ("Procurement Analytics", "ME2PN · ZMRP · Reports & alerts", "📊", "ME2PN", True),
    ("Material CSV Import",   "ZMMI · Two-step batch import",    "📥", "ZMMI",  True),
    ("Sales & Distribution",  "Sales orders & customer invoices","🏷️", "VA05",  False),
    ("Finance & Accounting",  "Ledger, journals & reconcile",    "💰", "FB50",  False),
    ("Human Resources",       "Employees, leave & attendance",   "👥", "PA30",  False),
    ("Production Planning",   "BOM, work orders & shop floor",   "🏭", "COOIS", False),
    ("Quality Management",    "Inspection lots & results",       "🔬", "QA32",  False),
    ("AURA 7 AI",             "AI‑powered ERP assistant",        "🤖", "AURA",  False),
    ("Administration",        "Users, roles & system settings",  "⚙️", "SU01",  False),
]

_LIVE_COLOR   = "#2563eb"   # blue outline highlight on hover for all tiles
_CARD_BG      = "#ffffff"   # clean white background — never blue
_CARD_BORDER  = "#e5e7eb"
_CARD_RADIUS  = "12px"


class _KpiTile(QFrame):
    """Summary KPI tile with outline highlight and elevated shadow effect on hover."""

    def __init__(self, label: str, value: str, color: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setFixedHeight(72)
        self.setMinimumWidth(180)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setBlurRadius(8)
        self._shadow.setOffset(0, 2)
        self._shadow.setColor(QColor(0, 0, 0, 18))
        self.setGraphicsEffect(self._shadow)

        self._apply_style(hover=False)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 10, 16, 10)
        layout.setSpacing(2)

        val_lbl = QLabel(value)
        val_lbl.setStyleSheet(f"font-size: 19px; font-weight: 700; color: {color};")
        layout.addWidget(val_lbl)

        lbl = QLabel(label)
        lbl.setStyleSheet("font-size: 10px; color: #4b5563; font-weight: 600; text-transform: uppercase;")
        layout.addWidget(lbl)

    def _apply_style(self, hover: bool) -> None:
        border = _LIVE_COLOR if hover else _CARD_BORDER
        if hover:
            self._shadow.setBlurRadius(18)
            self._shadow.setOffset(0, 4)
            self._shadow.setColor(QColor(0, 0, 0, 40))
        else:
            self._shadow.setBlurRadius(8)
            self._shadow.setOffset(0, 2)
            self._shadow.setColor(QColor(0, 0, 0, 18))

        self.setStyleSheet(
            f"QFrame {{ background: {_CARD_BG}; border: 1.5px solid {border};"
            f"border-radius: 10px; }}"
        )

    def enterEvent(self, event) -> None:
        self._apply_style(hover=True)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._apply_style(hover=False)
        super().leaveEvent(event)


class _ModuleCard(QFrame):
    """A module tile with outline highlight and drop shadow effect applied to all tiles."""

    def __init__(
        self,
        title: str,
        subtitle: str,
        icon: str,
        tcode: Optional[str],
        live: bool,
        navigate: Callable[[str], None],
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self._live = live
        self._tcode = tcode
        self._navigate = navigate

        self.setFixedSize(200, 160)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        # Drop shadow effect for the card and its outline
        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setBlurRadius(8)
        self._shadow.setOffset(0, 2)
        self._shadow.setColor(QColor(0, 0, 0, 18))
        self.setGraphicsEffect(self._shadow)

        self._apply_style(hover=False)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 12)
        layout.setSpacing(4)

        # Icon
        icon_lbl = QLabel(icon)
        icon_lbl.setFont(QFont("Segoe UI Emoji", 26))
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(icon_lbl)

        layout.addSpacing(4)

        # Title
        title_lbl = QLabel(title)
        title_lbl.setWordWrap(True)
        title_font = QFont()
        title_font.setPointSize(10)
        title_font.setBold(True)
        title_lbl.setFont(title_font)
        title_lbl.setStyleSheet(f"color: {'#111827' if live else '#6b7280'};")
        layout.addWidget(title_lbl)

        # Subtitle
        sub_lbl = QLabel(subtitle)
        sub_lbl.setWordWrap(True)
        sub_lbl.setStyleSheet("color: #6b7280; font-size: 10px;")
        layout.addWidget(sub_lbl)

        layout.addStretch(1)

        # Badge row
        badge_row = QHBoxLayout()
        badge_row.setContentsMargins(0, 0, 0, 0)

        if tcode:
            tcode_lbl = QLabel(tcode)
            tcode_lbl.setStyleSheet(
                f"color: white; background: {'#2563eb' if live else '#9ca3af'};"
                "border-radius: 4px; padding: 2px 6px; font-size: 10px; font-weight: 600;"
            )
            badge_row.addWidget(tcode_lbl)

        badge_row.addStretch(1)

        if not live:
            soon_lbl = QLabel("Coming Soon")
            soon_lbl.setStyleSheet(
                "color: #4b5563; background: #f3f4f6; border-radius: 4px;"
                "padding: 2px 6px; font-size: 10px; font-weight: 500;"
            )
            badge_row.addWidget(soon_lbl)

        layout.addLayout(badge_row)

    def _apply_style(self, hover: bool) -> None:
        # Background stays crisp white — ONLY the outline is highlighted on ALL tiles
        if hover:
            border = _LIVE_COLOR  # #2563eb highlight for all tiles
            self._shadow.setBlurRadius(20)
            self._shadow.setOffset(0, 5)
            self._shadow.setColor(QColor(0, 0, 0, 45))
        else:
            border = _CARD_BORDER
            self._shadow.setBlurRadius(8)
            self._shadow.setOffset(0, 2)
            self._shadow.setColor(QColor(0, 0, 0, 18))

        self.setStyleSheet(
            f"QFrame {{ background: {_CARD_BG}; border: 1.5px solid {border};"
            f"border-radius: {_CARD_RADIUS}; }}"
        )

    def enterEvent(self, event) -> None:
        self._apply_style(hover=True)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._apply_style(hover=False)
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._navigate(self._tcode or "COMING_SOON")
        super().mousePressEvent(event)


class DashboardWidget(QWidget):
    """
    Dashboard home screen.

    Shows a KPI banner at the top, a grid of ERP module tiles, and an
    animated background activity skeleton stream.
    """

    def __init__(self, navigate: Callable[[str], None], session: dict):
        super().__init__()
        self._navigate = navigate
        self._session = session
        self._build_ui()

    # ---------------------------------------------------------------- UI

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── welcome banner ───────────────────────────────────────────────
        banner = QFrame()
        banner.setStyleSheet(
            "background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            "stop:0 #1e3a8a, stop:1 #2563eb); border-radius: 0px;"
        )
        banner_layout = QVBoxLayout(banner)
        banner_layout.setContentsMargins(28, 20, 28, 20)
        banner_layout.setSpacing(4)

        who = self._session.get("full_name") or self._session.get("username") or "User"
        greet = QLabel(f"Welcome back, {who} 👋")
        greet.setStyleSheet("color: white; font-size: 18px; font-weight: 700;")
        banner_layout.addWidget(greet)

        tagline = QLabel("Brain ERP — Enterprise Resource Planning")
        tagline.setStyleSheet("color: #bfdbfe; font-size: 11px;")
        banner_layout.addWidget(tagline)

        root.addWidget(banner)

        # ── KPI strip with hoverable tiles ───────────────────────────────
        kpi_strip = QFrame()
        kpi_strip.setStyleSheet("background: #f8fafc; border-bottom: 1px solid #e5e7eb;")
        kpi_row = QHBoxLayout(kpi_strip)
        kpi_row.setContentsMargins(28, 14, 28, 14)
        kpi_row.setSpacing(16)

        kpis = [
            ("Materials Suite",  "100% Live", "#2563eb"),
            ("Active Modules",   "10 / 17",   "#16a34a"),
            ("API Endpoints",    "98 Active", "#0284c7"),
            ("System Status",    "Online",    "#059669"),
        ]
        for label, value, color in kpis:
            tile = _KpiTile(label, value, color, self)
            kpi_row.addWidget(tile)
        kpi_row.addStretch(1)

        root.addWidget(kpi_strip)

        # ── module grid & feeds (scrollable) ─────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("background: #f1f5f9;")

        inner = QWidget()
        inner.setStyleSheet("background: #f1f5f9; color: #111827;")
        inner_layout = QVBoxLayout(inner)
        inner_layout.setContentsMargins(28, 24, 28, 24)
        inner_layout.setSpacing(20)

        # section header
        section_lbl = QLabel("ERP Modules")
        section_lbl.setStyleSheet(
            "font-size: 14px; font-weight: 700; color: #111827;"
        )
        inner_layout.addWidget(section_lbl)

        grid = QGridLayout()
        grid.setSpacing(16)

        for idx, (title, subtitle, icon, tcode, live) in enumerate(_MODULES):
            card = _ModuleCard(title, subtitle, icon, tcode, live, self._navigate)
            row = idx // 4
            col = idx % 4
            grid.addWidget(card, row, col, Qt.AlignmentFlag.AlignTop)

        # fill remaining columns in last row so grid stays left-aligned
        total = len(_MODULES)
        remainder = total % 4
        if remainder:
            for c in range(remainder, 4):
                placeholder = QWidget()
                placeholder.setFixedSize(200, 160)
                last_row = total // 4
                grid.addWidget(placeholder, last_row, c)

        inner_layout.addLayout(grid)

        # ── Real-time Feeds / Background Sync section ────────────────────
        feed_header = QLabel("⚡ Live Sync & Background Feeds")
        feed_header.setStyleSheet("font-size: 13px; font-weight: 700; color: #111827; margin-top: 8px;")
        inner_layout.addWidget(feed_header)

        feed_sub = QLabel("Active background synchronizers with AURA 7 AI gateway.")
        feed_sub.setStyleSheet("font-size: 11px; color: #6b7280; margin-bottom: 6px;")
        inner_layout.addWidget(feed_sub)

        # Animated skeleton card row (warm-wasp-21)
        self.skeleton_row = SkeletonCardRow(count=3, parent=self)
        inner_layout.addWidget(self.skeleton_row)

        scroll.setWidget(inner)
        root.addWidget(scroll, 1)
